//
//  ViewController2.swift
//  SPISSUES
//
//  Created by Scholar on 8/16/22.
//

import UIKit

class ViewController2: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var UserNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var emojiTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UserNameTF.delegate = self
        emailTF.delegate = self
        emojiTF.delegate = self
        
        

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        nameOfUser = UserNameTF.text!
        emailOfUser = emailTF.text!
        emojiOfUser = emojiTF.text!
        
        
    }

    @IBAction func enterButtonTapped(_ sender: Any) {
        
    }
}
