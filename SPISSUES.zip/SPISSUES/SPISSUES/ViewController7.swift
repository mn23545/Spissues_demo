//
//  ViewController7.swift
//  SPISSUES
//
//  Created by Scholar on 8/17/22.
//

import UIKit

class ViewController7: UIViewController {
    
    @IBAction func signAPetition(_ sender: UIButton) {
        UIApplication.shared.open(URL(string: "https://chng.it/GFcvmRRjsy")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func gofundme(_ sender: UIButton) {
        UIApplication.shared.open(URL(string: "https://www.gofundme.com/f/fightback")! as URL, options: [:], completionHandler: nil)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //title = "Bar items"
       // view.backgroundColor = .lightGray
        
//        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
//        view.addSubview(button)
//        button.center = view.center
//        button.backgroundColor = .systemBlue
//        button.setTitle("Go to View 2", for: .normal)
//        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
//        configureItems()
        
        

        // Do any additional setup after loading the view.
    }
//    private func configureItems () {
//        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem:  .add, target: self, action: nil)
//    }
//
//    @objc func didTapButton(){
//        let vc = UIViewController()
//        navigationController?.pushViewController(vc, animated: true)
//    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
