//
//  globalVariables.swift
//  SPISSUES
//
//  Created by Scholar on 8/16/22.
//

public var nameOfUser = ""
public var  emailOfUser = ""
public var emojiOfUser = ""
